﻿namespace bike
{
    internal class Click
    {
    }
}